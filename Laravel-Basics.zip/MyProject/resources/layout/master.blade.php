<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h1>Navbar In Master</h1>

@yield('body')
</body>
</html>