
<h2>Subjects & Marks</h2>

<h3>{!! $subjects !!}</h3> //It will show alert script
<br>
{{ $subjects }} // It will not show alert script
<br>
@{{ $subjects }} //It will show code of laravel
<br><br>
<?php
//print_r($subjects);
$NotFound="Data Not Found";
//print_r($marks);
?>

@if($ifelse == "Hello")
{{ $ifelse }}
@elseif($ifelse == "hi")
{{ $ifelse }}
@else
{{ $NotFound }}
@endif

