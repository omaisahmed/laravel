<form action="{{ route('contactstore') }}" method=post>

@if($errors->any())
  @foreach($errors->all() as $error)
   <li>{{ $error }}</li>
   @endforeach

@endif   

{{ csrf_field() }}

	<label for="name">Email</label>
	<input type="text" name="email">
	<input type="submit">
</form>