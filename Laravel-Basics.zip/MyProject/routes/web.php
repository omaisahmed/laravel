<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get("sayhello/{fname}","Hellocontroller@index");

Route::get("demo/{price}",function($price){
	echo $price;
})->where(['price'=>"[0-9]+"]);

Route::get("pricefilter/{max}/{min?}",function($max,$min='0'){
	echo " max = ".$max." min = ".$min;
});

Route::get("hello","Hellocontroller@index")->middleware("test");

Route::get("controller","Hellocontroller@index");
Route::get("requestcontroller","RequestController@index");

Route::get("/","ContactController@index");
Route::post("/contact","ContactController@store")->name("contactstore");



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
