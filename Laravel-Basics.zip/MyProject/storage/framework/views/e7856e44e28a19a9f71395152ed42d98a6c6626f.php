
<h2>Subjects & Marks</h2>

<h3><?php echo $subjects; ?></h3> //It will show alert script
<br>
<?php echo e($subjects); ?> // It will not show alert script
<br>
{{ $subjects }} //It will show code of laravel
<br><br>
<?php
//print_r($subjects);
$NotFound="Data Not Found";
//print_r($marks);
?>

<?php if($ifelse == "Hello"): ?>
<?php echo e($ifelse); ?>

<?php elseif($ifelse == "hi"): ?>
<?php echo e($ifelse); ?>

<?php else: ?>
<?php echo e($NotFound); ?>

<?php endif; ?>

