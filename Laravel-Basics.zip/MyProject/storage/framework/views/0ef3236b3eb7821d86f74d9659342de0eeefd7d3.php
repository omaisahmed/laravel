<form action="<?php echo e(route('contactstore')); ?>" method=post>

<?php if($errors->any()): ?>
  <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <li><?php echo e($error); ?></li>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php endif; ?>   

<?php echo e(csrf_field()); ?>


	<label for="name">Email</label>
	<input type="text" name="email">
	<input type="submit">
</form>