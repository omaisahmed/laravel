<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\Student;
use App\Teacher;

class Hellocontroller extends Controller
{
	public function index(){
		$subjects="<script>alert('Data Inserted Successfully')</script>";
		$ifelse="Hello";
		$marks=[70,56,78];

	//return view("hello")->with(["subjects"=>$subjects,"marks"=>$marks]);
	//$array=['sname' => 'bilal','standard' => '12'];
    $student=new Teacher(['sname' => 'bilal','standard' => '12']);
    //$student->sname = "omais";
    //$student->standard = 11;
    $student->save();


		return view("hello")->with(["subjects"=>$subjects])->with(["ifelse"=>$ifelse]);
	}
}