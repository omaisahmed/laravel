<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RequestController extends Controller
{
    public function index(Request $request){
    	//dd($request->name);
    	echo $request->get("name","Name Not Found");
    }
}
